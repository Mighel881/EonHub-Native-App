//
//  ContentView.swift
//  EonHub Native
//
//  Created by CaspD3V on 10/21/20.
//

import SwiftUI
import SDWebImageSwiftUI

struct ContentView: View {
    
    @ObservedObject var ContentVM = Webservice()
    init() {
        ContentVM.getAllPosts()
        }
    
    var body: some View {
        NavigationView{
            ScrollView{
            VStack{
                ForEach(ContentVM.postData){ post in
                HStack {
                    WebImage(url: URL(string: "https://app.eonhubapp.com/images/icons/\(post.icon)")).resizable().frame(width:50,height:50).cornerRadius(15)
                        .padding(.leading)
                    VStack (alignment: .leading){
                        Text("\(post.name)")
                            .fontWeight(.bold)
                        Text("\(post.dev)")
                            .font(.footnote)
                            .foregroundColor(Color.gray)
                    }
                    Spacer()
                    Button(action: {
                        if let url = URL(string: "itms-services://?action=download-manifest&url=https://eonhubapp.com/plists/\(post.plist).plist") {
                            UIApplication.shared.open(url)
                        }
                    })
                    {
                        Text("Get").foregroundColor(Color.white)
                    }.frame(width:60,height:35).background(Color.pink).cornerRadius(20).padding(.horizontal)
                }
                }
                }
            }
            
            
            
            
            .padding()
            .navigationBarTitle("EonHub")
            .navigationBarItems(leading: Text("Welcome"))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
