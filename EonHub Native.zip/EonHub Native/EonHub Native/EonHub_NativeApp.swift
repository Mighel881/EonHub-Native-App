//
//  EonHub_NativeApp.swift
//  EonHub Native
//
//  Created by CaspD3V on 10/21/20.
//

import SwiftUI

@main
struct EonHub_NativeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
