//
//  Webservices.swift
//  EonHub Native
//
//  Created by CaspD3V on 10/21/20.
//

import Foundation

struct Post: Decodable, Hashable, Identifiable{
    let id = UUID()
    var icon: String
    var name: String
    var dev: String
    var plist: String
}
class Webservice: ObservableObject {
    @Published var postData = [Post]()
    func getAllPosts() {

        guard let url = URL(string: "https://eonhubapp.com/all.json")
        else {
        fatalError("Wrong URL")
            return
        }
        let dataTask = try! URLSession.shared.dataTask(with: url) { (data, _ , error) in
            if error == nil && data != nil {
                let jsonData = try! JSONDecoder().decode([Post].self, from: data!)
                for i in jsonData {
                    self.postData.append(Post(icon: i.icon, name: i.name, dev: i.dev, plist: i.plist))
                }
                } else {
                    print("failed To Grab")
                    return
                }
            }
        dataTask.resume()
        }
    }
